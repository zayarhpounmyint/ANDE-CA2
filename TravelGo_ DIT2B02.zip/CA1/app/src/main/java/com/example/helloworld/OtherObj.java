package com.example.helloworld;

import java.time.ZonedDateTime;

public class OtherObj extends Activity_Obj{
    private String note;

    public OtherObj() {
    }

    public OtherObj(String name,ZonedDateTime activityStartTime, ZonedDateTime activityEndTime, String note) {
        super(name, activityStartTime, activityEndTime);
        this.note = note;
    }

    public OtherObj(String name){
        this.setActivity_Name( name );
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
