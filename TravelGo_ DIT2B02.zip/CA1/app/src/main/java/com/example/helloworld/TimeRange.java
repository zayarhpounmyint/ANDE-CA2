package com.example.helloworld;

import java.time.ZonedDateTime;

public class TimeRange {
        private int index;
        private ZonedDateTime startTime;
        private ZonedDateTime endTime;

        public TimeRange(int index,ZonedDateTime startTime, ZonedDateTime endTime) {
            this.index = index;
            this.startTime = startTime;
            this.endTime = endTime;
        }

    public ZonedDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(ZonedDateTime startTime) {
        this.startTime = startTime;
    }

    public ZonedDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(ZonedDateTime endTime) {
        this.endTime = endTime;
    }

    public int getIndex() {
        return index;
    }
}
