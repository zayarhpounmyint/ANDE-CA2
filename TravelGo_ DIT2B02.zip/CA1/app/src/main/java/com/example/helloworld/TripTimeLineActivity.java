package com.example.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class TripTimeLineActivity extends AppCompatActivity {

    private RecyclerView recycleView;
    private RecycleArrayAdapterTrip adapter;
    private TripPlanObj tripPlanObj;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triptimeline);
        Intent intentReceive = getIntent();
        tripPlanObj = (TripPlanObj)intentReceive.getSerializableExtra("item");

        ImageButton back_btn_trip = findViewById(R.id.back_btn_trip);
        back_btn_trip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start to go back to MainActivity
                Intent intent = new Intent(TripTimeLineActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        if (intentReceive != null) {
            adapter = new RecycleArrayAdapterTrip(tripPlanObj.getActivities());
            recycleView.setAdapter(adapter);
        }




    }



}
