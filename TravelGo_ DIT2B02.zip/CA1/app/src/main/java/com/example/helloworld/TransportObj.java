package com.example.helloworld;

import java.time.Duration;
import java.util.Date;

public class TransportObj extends Activity_Obj {

    private String transportType;
    private Date date;
    private String depLocation;
    private String arrLocation;
    private String timeZone;
    private String Note;

    public TransportObj() {
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDepLocation() {
        return depLocation;
    }

    public void setDepLocation(String depLocation) {
        this.depLocation = depLocation;
    }

    public String getArrLocation() {
        return arrLocation;
    }

    public void setArrLocation(String arrLocation) {
        this.arrLocation = arrLocation;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String note) {
        Note = note;
    }

    @Override
    public String getDisplayText(){
        Duration duration = Duration.between(this.getActivityEndTime(),this.getActivityEndTime());
        long hours = duration.toHours();
        long minutes = duration.toMinutes() % 60;
        String formattedResult = String.format("%dh%02dmins", hours, minutes);
        String i = this.depLocation + " - " + this.arrLocation + "\nest. " + formattedResult;
        return i;
    }
}
