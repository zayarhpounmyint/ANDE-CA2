package com.example.helloworld;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import androidx.appcompat.app.AppCompatActivity;

public class AddFlightActivity extends AppCompatActivity {
    DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_addflight); // Assuming your layout file is named activity_add_flight.xml

            Button saveButton = findViewById(R.id.saveBtn2);

            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle save button click
                    saveFlight(); // You can call a method or add your save logic here
                }
            });
        }

    private void saveFlight() {
        // Implement your save logic here
        // For example, you can retrieve data from EditText fields and save it to a database
        FlightObj flight = new FlightObj();
        EditText editTextDate = findViewById(R.id.editTextDate);
        EditText editTextDTime = findViewById(R.id.editTextDTime);
        EditText editTextATime = findViewById(R.id.editTextATime);
        EditText editTextFN = findViewById(R.id.editTextFN);
        EditText editTextAL2 = findViewById(R.id.editTextAL2);
        EditText editTextSN = findViewById(R.id.editTextSN);
        EditText editTextDA = findViewById(R.id.editTextDA);
        EditText editTextDC = findViewById(R.id.editTextDC);
        EditText editTextDTer = findViewById(R.id.editTextDTer);
        EditText editTextDG = findViewById(R.id.editTextDG);
        EditText editTextAA = findViewById(R.id.editTextAA);
        EditText editTextAC = findViewById(R.id.editTextAC);
        EditText editTextATer = findViewById(R.id.editTextATer);
        EditText editTextAG = findViewById(R.id.editTextAG);
        Spinner spinnerDTZ = findViewById(R.id.spinnerDTZ);
        Spinner spinnerCTZ = findViewById(R.id.spinnerCTZ);
        flight.setFlightNo(editTextFN.getText().toString());
        flight.setAirline((editTextAL2.getText().toString()));
        flight.setSeatNo((editTextSN.getText().toString()));
        flight.setDepAirport((editTextDA.getText().toString()));
        flight.setDepCity((editTextDC).getText().toString());
        //ZonedDateTime zonedDateTime = convertToZonedDateTime(editTextDate.getText().toString()) ;
        flight.setActivityStartTime(ZonedDateTime.parse(editTextDTime.getText().toString(), formatter));
        flight.setDepTerminal(editTextDTer.getText().toString());
        flight.setGate(editTextDG.getText().toString());
        flight.setArrAirport(editTextAA.getText().toString());
        flight.setArrCity(editTextAC.getText().toString());
        flight.setActivityEndTime(ZonedDateTime.parse(editTextATime.getText().toString(),formatter));
        flight.setArrTerminal(editTextATer.getText().toString());




    }
    }


