package com.example.helloworld;

import java.util.Date;

public class RestaurantObj extends Activity_Obj{
    private String dinType;
    private String restaurantName;
    private Date date;
    private String address;
    private String website;
    private String note;

    public RestaurantObj() {
    }

    public String getDinType() {
        return dinType;
    }

    public void setDinType(String dinType) {
        this.dinType = dinType;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String getDisplayText(){
        String i = this.restaurantName + "\nNote: " + this.note;
        return i;
    }
}
