package com.example.helloworld;

import java.util.Date;

public class AttractionObj extends Activity_Obj{
    private String attractionName;
    private Date date;
    private String address;
    private String note;
    private  String category;

    public AttractionObj() {
    }

    public String getAttractionName() {
        return attractionName;
    }

    public void setAttractionName(String attractionName) {
        this.attractionName = attractionName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String getDisplayText(){
        String i = this.attractionName + "\n" + this.address+"\nNote:" + this.note;
        return i;
    }
}
