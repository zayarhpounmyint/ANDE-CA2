package com.example.helloworld;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AllTripListRecycleActivity extends AppCompatActivity {
    private RecyclerView recycleView;
    private AllTripListRecycleAdapter adapter;
    private DatabaseHandler db;
    private List<TripPlanObj> trips;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alltripplans);


        db = new DatabaseHandler(this);

        trips = db.getAllTripPlan();

        recycleView = findViewById(R.id.allTripRecycleView);
        recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AllTripListRecycleAdapter();
        recycleView.setAdapter(adapter);

        // Load food category items automatically when the page loads

        adapter.getAllTripList(trips);

    }

}

