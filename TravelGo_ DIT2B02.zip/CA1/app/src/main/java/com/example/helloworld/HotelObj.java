package com.example.helloworld;

import java.util.Date;

public class HotelObj extends Activity_Obj{
    private String hotelName;
    private Date date;
    private String address;
    private String website;
    private String Note;

    public HotelObj() {
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String note) {
        Note = note;
    }

    @Override
    public String getDisplayText(){
        String i = this.hotelName + "\n" + this.address + "\nNote: " + this.Note;
        return i;
    }
}
