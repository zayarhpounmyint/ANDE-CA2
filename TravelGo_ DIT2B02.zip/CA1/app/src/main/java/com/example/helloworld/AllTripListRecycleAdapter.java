package com.example.helloworld;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.format.DateTimeFormatter;
import java.util.List;



public class AllTripListRecycleAdapter extends RecyclerView.Adapter<AllTripListRecycleAdapter.ViewHolder> {
    private List<TripPlanObj> items;
    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("E, MMM d");

    public void getAllTripList(List<TripPlanObj> tripLists){
        this.items = tripLists;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.alltripplan_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TripPlanObj item = items.get(position);
        holder.textTitle.setText(item.getTripName());
        holder.textDescription.setText(item.getEndTime().format(formatter2) + " - " + item.getEndTime().format((formatter2)));
        holder.btnViewDetails.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Start DetailsActivity and pass data
                Context context = v.getContext();
                Intent intent = new Intent(context, TripTimeLineActivity.class);
                intent.putExtra("item",item);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textTitle;
        TextView textDescription;
        Button btnViewDetails;


        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle= itemView.findViewById(R.id.alltriplistitemHeader);
            textDescription = itemView.findViewById(R.id.allTripItemDate);
            btnViewDetails=itemView.findViewById(R.id.tripdetailListFromAllBtn);

        }
    }


}
