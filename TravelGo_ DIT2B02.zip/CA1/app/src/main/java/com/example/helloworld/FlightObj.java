package com.example.helloworld;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class FlightObj extends Activity_Obj {
    private Date departureDate;
    private String flightNo;
    private String airline;
    private String seatNo;
    private String depAirport;
    private String depCity;
    private String depTimeZone;
    private String depTerminal;
    private String gate;
    private String arrAirport;
    private String arrCity;
    private String arrTimeZone;
    private String arrTerminal;


    public FlightObj() {
    }

    public FlightObj(String activity_Name, ZonedDateTime activityStartTime, ZonedDateTime activityEndTime, Date departureDate, String flightNo, String airline, String seatNo, String depAirport, String depCity, String depTimeZone, String depTerminal, String gate, String arrAirport, String arrCity, String arrTimeZone, String arrTerminal) {
        super(activity_Name, activityStartTime, activityEndTime);
        this.departureDate = departureDate;
        this.flightNo = flightNo;
        this.airline = airline;
        this.seatNo = seatNo;
        this.depAirport = depAirport;
        this.depCity = depCity;
        this.depTimeZone = depTimeZone;
        this.depTerminal = depTerminal;
        this.gate = gate;
        this.arrAirport = arrAirport;
        this.arrCity = arrCity;
        this.arrTimeZone = arrTimeZone;
        this.arrTerminal = arrTerminal;
    }

    public Date getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(Date departureDate) {
        this.departureDate = departureDate;
    }

    public String getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(String flightNo) {
        this.flightNo = flightNo;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline;
    }

    public String getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(String seatNo) {
        this.seatNo = seatNo;
    }

    public String getDepAirport() {
        return depAirport;
    }

    public void setDepAirport(String depAirport) {
        this.depAirport = depAirport;
    }

    public String getDepCity() {
        return depCity;
    }

    public void setDepCity(String depCity) {
        this.depCity = depCity;
    }

    public String getDepTimeZone() {
        return depTimeZone;
    }

    public void setDepTimeZone(String depTimeZone) {
        this.depTimeZone = depTimeZone;
    }

    public String getDepTerminal() {
        return depTerminal;
    }

    public void setDepTerminal(String depTerminal) {
        this.depTerminal = depTerminal;
    }

    public String getGate() {
        return gate;
    }

    public void setGate(String gate) {
        this.gate = gate;
    }

    public String getArrAirport() {
        return arrAirport;
    }

    public void setArrAirport(String arrAirport) {
        this.arrAirport = arrAirport;
    }

    public String getArrCity() {
        return arrCity;
    }

    public void setArrCity(String arrCity) {
        this.arrCity = arrCity;
    }

    public String getArrTimeZone() {
        return arrTimeZone;
    }

    public void setArrTimeZone(String arrTimeZone) {
        this.arrTimeZone = arrTimeZone;
    }

    public String getArrTerminal() {
        return arrTerminal;
    }

    public void setArrTerminal(String arrTerminal) {
        this.arrTerminal = arrTerminal;
    }

    @Override
    public String getDisplayText(){
        Duration duration = Duration.between(this.getActivityEndTime(),this.getActivityEndTime());
        long hours = duration.toHours();
        long minutes = duration.toMinutes() % 60;
        String formattedResult = String.format("%dh%02dmins", hours, minutes);

        String i = this.depCity + " - " + this.arrCity + "\n" +this.airline + "\n" + this.depTerminal + "\nArrival: "
                + this.getActivityEndTime().format(DateTimeFormatter.ofPattern("hh:mm a")) + "(UTC" +this.getActivityStartTime().getOffset()
                + ")\nest. " + formattedResult;
        return i;
    }
}
