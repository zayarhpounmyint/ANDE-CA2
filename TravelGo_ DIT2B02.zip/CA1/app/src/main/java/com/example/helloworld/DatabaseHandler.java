package com.example.helloworld;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "AttractionApp";
    //attractions
    private static final String TABLE_ATTRACTIONS = "attractions";
    private static final String KEY_ID = "id";
    private static final String KEY_CATEGORY = "category";
    private static final String KEY_IMAGE = "image";
    private static final String KEY_TITLE = "title";
    private static final String KEY_DESCRIPTION = "description";
    private static final String KEY_RATING = "rating";
    private static final String KEY_LOCATION = "location";
    private static final String KEY_DISTANCE = "distance";
    private static final String KEY_WEBSITE = "website";

    // cities
    private static final String TABLE_CITIES = "cities";
    private static final String KEY_CITY_ID = "id";
    private static final String KEY_CITY_TITLE = "title";
    private static final String KEY_CITY_IMAGE = "imageResource";
    private static final String KEY_CITY_DESCRIPTION = "description";
    private static final String KEY_CITY_CATEGORY = "category";

    // comments
    private static final String TABLE_COMMENTS = "comments";
    private static final String KEY_COMMENT_ID = "id";
    private static final String KEY_COMMENT_ATTRACTION_ID = "attraction_id";
    private static final String KEY_COMMENT_USERNAME = "username";
    private static final String KEY_COMMENT_COMMENT = "comment";

    //trip
    private static final String TABLE_NAME = "tripList";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_SERIALIZED_DATA = "serialized_data";




    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ATTRACTIONS_TABLE = "CREATE TABLE " + TABLE_ATTRACTIONS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_CATEGORY + " TEXT,"
                + KEY_IMAGE + " INTEGER," + KEY_TITLE + " TEXT,"
                + KEY_DESCRIPTION + " TEXT," + KEY_RATING + " REAL,"
                + KEY_LOCATION + " REAL," + KEY_DISTANCE + " REAL,"
                + KEY_WEBSITE + " TEXT" + ")";
        db.execSQL(CREATE_ATTRACTIONS_TABLE);


        String CREATE_CITIES_TABLE = "CREATE TABLE " + TABLE_CITIES + "("
                + KEY_CITY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_CITY_TITLE + " TEXT,"
                + KEY_CITY_IMAGE + " INTEGER,"
                + KEY_CITY_DESCRIPTION + " TEXT,"
                + KEY_CITY_CATEGORY + " TEXT" + ")";
        db.execSQL(CREATE_CITIES_TABLE);


        String CREATE_COMMENTS_TABLE = "CREATE TABLE " + TABLE_COMMENTS + "("
                + KEY_COMMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_COMMENT_ATTRACTION_ID + " INTEGER,"
                + KEY_COMMENT_USERNAME + " TEXT,"
                + KEY_COMMENT_COMMENT + " TEXT,"
                + "FOREIGN KEY(" + KEY_COMMENT_ATTRACTION_ID + ") REFERENCES "
                + TABLE_ATTRACTIONS + "(" + KEY_ID + "))";
        db.execSQL(CREATE_COMMENTS_TABLE);

        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_SERIALIZED_DATA + " BLOB)";
        db.execSQL(createTableQuery);
    }


    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ATTRACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CITIES);
        onCreate(db);
    }

    // code to add the new attraction
    public void addAttraction(Attraction attraction) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CATEGORY, attraction.getCategory());
        values.put(KEY_IMAGE, attraction.getImage());
        values.put(KEY_TITLE, attraction.getTitle());
        values.put(KEY_DESCRIPTION, attraction.getDescription());
        values.put(KEY_RATING, attraction.getRating());
        values.put(KEY_LOCATION, attraction.getLocation());
        values.put(KEY_DISTANCE, attraction.getDistance());
        values.put(KEY_WEBSITE, attraction.getWebsite());

        db.insert(TABLE_ATTRACTIONS, null, values);
        db.close();
    }

    // code to get the single attraction
    public Attraction getAttraction(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_ATTRACTIONS, new String[] { KEY_ID,
                        KEY_CATEGORY, KEY_IMAGE, KEY_TITLE, KEY_DESCRIPTION, KEY_RATING, KEY_LOCATION, KEY_DISTANCE, KEY_WEBSITE }, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Attraction attraction = new Attraction(
                cursor.getInt(0), // ID
                cursor.getString(1), // Category
                cursor.getInt(2), // Image
                cursor.getString(3), // Title
                cursor.getString(4), // Description
                cursor.getDouble(5), // Rating
                cursor.getString(6), // Location
                cursor.getDouble(7), // Distance
                cursor.getString(8)  // Website
        );
        cursor.close();
        return attraction;
    }

    public List<Attraction> getAttractionsByCategory(String category) {
        List<Attraction> attractionList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_ATTRACTIONS, new String[] { KEY_ID, KEY_CATEGORY, KEY_IMAGE, KEY_TITLE, KEY_DESCRIPTION, KEY_RATING, KEY_LOCATION, KEY_DISTANCE, KEY_WEBSITE },
                KEY_CATEGORY + "=?", new String[] { category }, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                Attraction attraction = new Attraction(
                        cursor.getInt(0), // ID
                        cursor.getString(1), // Category
                        cursor.getInt(2), // Image
                        cursor.getString(3), // Title
                        cursor.getString(4), // Description
                        cursor.getDouble(5), // Rating
                        cursor.getString(6), // Location
                        cursor.getDouble(7), // Distance
                        cursor.getString(8)  // Website
                );
                attractionList.add(attraction);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return attractionList;
    }


    // code to get all attractions in a list view
    public List<Attraction> getAllAttractions() {
        List<Attraction> attractionList = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + TABLE_ATTRACTIONS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Attraction attraction = new Attraction(
                        cursor.getInt(0), // ID
                        cursor.getString(1), // Category
                        cursor.getInt(2), // Image
                        cursor.getString(3), // Title
                        cursor.getString(4), // Description
                        cursor.getDouble(5), // Rating
                        cursor.getString(6), // Location
                        cursor.getDouble(7), // Distance
                        cursor.getString(8)  // Website
                );
                attractionList.add(attraction);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return attractionList;
    }

    // code to update the single attraction
    public int updateAttraction(Attraction attraction) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CATEGORY, attraction.getCategory());
        values.put(KEY_IMAGE, attraction.getImage());
        values.put(KEY_TITLE, attraction.getTitle());
        values.put(KEY_DESCRIPTION, attraction.getDescription());
        values.put(KEY_RATING, attraction.getRating());
        values.put(KEY_DISTANCE, attraction.getLocation());
        values.put(KEY_DISTANCE, attraction.getDistance());
        values.put(KEY_WEBSITE, attraction.getWebsite());

        return db.update(TABLE_ATTRACTIONS, values, KEY_ID + " = ?",
                new String[] { String.valueOf(attraction.getId()) });
    }

    // Deleting single attraction
    public void deleteAttraction(Attraction attraction) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ATTRACTIONS, KEY_ID + " = ?",
                new String[] { String.valueOf(attraction.getId()) });
        db.close();
    }

    // Getting attractions count
    public int getAttractionsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_ATTRACTIONS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();

        return count;
    }

    public List<Attraction> searchAttractionsByTitle(String title) {
        List<Attraction> attractionList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_ATTRACTIONS, new String[] { KEY_ID, KEY_CATEGORY, KEY_IMAGE, KEY_TITLE, KEY_DESCRIPTION, KEY_RATING, KEY_LOCATION, KEY_DISTANCE, KEY_WEBSITE },
                KEY_TITLE + " LIKE ?", new String[] { "%" + title + "%" }, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                // Assuming you have a constructor in your Attraction class that matches this data
                @SuppressLint("Range") Attraction attraction = new Attraction(
                        cursor.getInt(cursor.getColumnIndex(KEY_ID)), // ID
                        cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)), // Category
                        cursor.getInt(cursor.getColumnIndex(KEY_IMAGE)), // Image
                        cursor.getString(cursor.getColumnIndex(KEY_TITLE)), // Title
                        cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION)), // Description
                        cursor.getDouble(cursor.getColumnIndex(KEY_RATING)), // Rating
                        cursor.getString(cursor.getColumnIndex(KEY_LOCATION)), // Location
                        cursor.getDouble(cursor.getColumnIndex(KEY_DISTANCE)), // Distance
                        cursor.getString(cursor.getColumnIndex(KEY_WEBSITE))  // Website
                );
                attractionList.add(attraction);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return attractionList;
    }

    // Method to add a new city
    public void addCity(City city) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CITY_TITLE, city.getTitle());
        values.put(KEY_CITY_IMAGE, city.getImageResource());
        values.put(KEY_CITY_DESCRIPTION, city.getDescription());
        values.put(KEY_CITY_CATEGORY, city.getCategory());

        db.insert(TABLE_CITIES, null, values);
        db.close();
    }

    // Method to get all cities
    public List<City> getAllCities() {
        List<City> cityList = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + TABLE_CITIES;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") City city = new City(
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_TITLE)),
                        cursor.getInt(cursor.getColumnIndex(KEY_CITY_IMAGE)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_DESCRIPTION)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_CATEGORY))
                );
                cityList.add(city);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return cityList;
    }

    // Method to get cities by category
    public List<City> getCitiesByCategory(String category) {
        List<City> cityList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_CITIES, new String[]{
                        KEY_CITY_ID, KEY_CITY_TITLE, KEY_CITY_IMAGE, KEY_CITY_DESCRIPTION, KEY_CITY_CATEGORY},
                KEY_CITY_CATEGORY + "=?", new String[]{category}, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") City city = new City(
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_TITLE)),
                        cursor.getInt(cursor.getColumnIndex(KEY_CITY_IMAGE)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_DESCRIPTION)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_CATEGORY))
                );
                cityList.add(city);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return cityList;
    }

    public List<City> searchCityName(String searchInput) {
        List<City> cityList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = KEY_CITY_TITLE + " LIKE ?";
        String[] selectionArgs = new String[] { "%" + searchInput + "%" };

        Cursor cursor = db.query(TABLE_CITIES, new String[] {
                        KEY_CITY_ID, KEY_CITY_TITLE, KEY_CITY_IMAGE, KEY_CITY_DESCRIPTION, KEY_CITY_CATEGORY},
                selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") City city = new City(
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_TITLE)),
                        cursor.getInt(cursor.getColumnIndex(KEY_CITY_IMAGE)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_DESCRIPTION)),
                        cursor.getString(cursor.getColumnIndex(KEY_CITY_CATEGORY))
                );
                cityList.add(city);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return cityList;
    }


    public int getCityCount() {
        String countQuery = "SELECT  * FROM " + TABLE_CITIES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();

        return count;
    }

    // Method to add a new comment
    public void addComment(Comment comment) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_COMMENT_ATTRACTION_ID, comment.getAttractionId());
        values.put(KEY_COMMENT_USERNAME, comment.getUsername());
        values.put(KEY_COMMENT_COMMENT, comment.getComment());

        db.insert(TABLE_COMMENTS, null, values);
        db.close();
    }

    // Method to get all comments for attraction
    public List<Comment> getCommentsForAttraction(int attractionId) {
        List<Comment> comments = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_COMMENTS, new String[] {
                        KEY_COMMENT_ID, KEY_COMMENT_ATTRACTION_ID, KEY_COMMENT_USERNAME, KEY_COMMENT_COMMENT },
                KEY_COMMENT_ATTRACTION_ID + "=?", new String[] { String.valueOf(attractionId) }, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") Comment comment = new Comment(
                        cursor.getInt(cursor.getColumnIndex(KEY_COMMENT_ID)), // Comment ID
                        cursor.getInt(cursor.getColumnIndex(KEY_COMMENT_ATTRACTION_ID)), // Attraction ID
                        cursor.getString(cursor.getColumnIndex(KEY_COMMENT_USERNAME)), // Username
                        cursor.getString(cursor.getColumnIndex(KEY_COMMENT_COMMENT)) // Comment
                );
                comments.add(comment);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return comments;
    }

    public void insertTripPlan(TripPlanObj tripPlan) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Serialize the linked list to a byte array
        byte[] serializedData = serialize(tripPlan);
        values.put(COLUMN_SERIALIZED_DATA, serializedData);

        // Insert the serialized data into the database
        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    public TripPlanObj getTripPlan(UUID id) {
        TripPlanObj tripPlan = new TripPlanObj();
        SQLiteDatabase db = this.getReadableDatabase();

        // Define the columns you want to retrieve
        String[] projection = {
                COLUMN_SERIALIZED_DATA
        };

        // Execute the query
        Cursor cursor = db.query(
                TABLE_NAME,
                new String[] { COLUMN_ID},
                null,
                null,
                null,
                null,
                null
        );

        // Process the cursor to retrieve data
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") byte[] serializedData = cursor.getBlob(cursor.getColumnIndex(COLUMN_SERIALIZED_DATA));

            // Deserialize the byte array back into a linked list
            tripPlan = deserialize(serializedData);

            // Close the cursor when done
            cursor.close();
        }

        // Close the database when done
        db.close();

        return tripPlan;
    }

    public List<TripPlanObj> getAllTripPlan() {
        List<TripPlanObj> tripLists = new ArrayList<>();

        String selectQuery = "SELECT  * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") TripPlanObj trip =
                        deserialize(cursor.getBlob(cursor.getColumnIndex(COLUMN_SERIALIZED_DATA)));
                tripLists.add(trip);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return tripLists;
    }

    private byte[] serialize(Object object) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(object);
            oos.close();
            return bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private TripPlanObj deserialize(byte[] data) {
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(bis);
            TripPlanObj tripPlan = (TripPlanObj) ois.readObject();
            ois.close();
            return tripPlan;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new TripPlanObj();
        }

    }

}
