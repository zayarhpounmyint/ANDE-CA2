package com.example.helloworld;



import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class TripPlanObj implements Serializable {
    private LinkedList<Activity_Obj> activities;
    private UUID id;
    //private ArrayList<OtherObj> blankActivities;
    private ZonedDateTime startTime;
    private ZonedDateTime endTime;
    private String tripName;




    public TripPlanObj() {
        this.activities = new LinkedList<Activity_Obj>();
        this.id = generateId();
    }

    public TripPlanObj(LinkedList<Activity_Obj> activities, UUID id, ZonedDateTime startTime, ZonedDateTime endTime, String tripName) {
        this.activities = activities;
        this.id = id;
        this.startTime = startTime;
        this.endTime = endTime;
        this.tripName = tripName;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public void addActivity(Activity_Obj activity) {
        if (this.activities.size() == 0) {
            activities.add(activity);
            this.startTime = activity.getActivityStartTime();
            this.endTime = activity.getActivityEndTime();
            return;

        } else if (ifBlankExist(activity) >-1) {
            activities.add(ifBlankExist(activity)+1,activity);
            return;
        } else if (activity.getActivityStartTime().compareTo(this.endTime) > 0) {
            //OtherObj blankObj = new OtherObj("Blank",this.endTime, activity.getActivityStartTime(),"");
            //activities.add(blankObj);
            //blankActivities.add(blankObj);
            activities.addLast(activity);
            this.endTime = activities.getLast().getActivityEndTime();
            return;
        }else if (activity.getActivityEndTime().compareTo(this.startTime) < 0){
            activities.addFirst(activity);
            this.startTime = activities.getFirst().getActivityStartTime();
            return;

//        } else if (activity.getActivityStartTime().compareTo(this.endTime) == 0) {
//            activities.add(activity);
//            this.endTime = activity.getActivityEndTime();
//            return;
//
//        } else if (activity.getActivityStartTime().compareTo(this.endTime) < 0) {
//            //OtherObj blankObj = new OtherObj("Blank",this.endTime, activity.getActivityStartTime(),"");
//            //activities.add(blankObj);
//            //blankActivities.add(blankObj);
//            activities.add(activity);
//            this.endTime = activities.getLast().getActivityEndTime();
//            return;
//
       } else {
           return;
        }
    }


    public List<TimeRange> getBlankTime() {
        List<TimeRange> zonedDateTimeListBlank = new LinkedList<>();
        for (int i = 0; i < activities.size(); i++) {
            if (activities.get(i).getActivityEndTime().isBefore(activities.get(i + 1).getActivityStartTime())) {
                zonedDateTimeListBlank.add(new TimeRange(i,activities.get(i).getActivityEndTime(), activities.get(i + 1).getActivityStartTime()));

            }
        }
        return zonedDateTimeListBlank;

    }

    public int ifBlankExist(Activity_Obj activity){
        List<TimeRange> zonedDateTimeListBlank = getBlankTime();
        for (int i = 0; i < zonedDateTimeListBlank.size(); i++){
            if(activity.getActivityStartTime().isAfter(zonedDateTimeListBlank.get(i).getStartTime())&&activity.getActivityEndTime().isBefore(zonedDateTimeListBlank.get(i).getEndTime())){
                return  zonedDateTimeListBlank.get(i).getIndex();
            }
        }
        return -1;
    }

    public void removeActivity(int i) {

        activities.remove(i);


    }
    private static UUID generateId(){

        UUID uuid = UUID.randomUUID();
        return uuid;
    }

    public LinkedList<Activity_Obj> getActivities() {
        return activities;
    }

    public void setActivities(LinkedList<Activity_Obj> activities) {
        this.activities = activities;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public ZonedDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(ZonedDateTime startTime) {
        this.startTime = startTime;
    }

    public ZonedDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(ZonedDateTime endTime) {
        this.endTime = endTime;
    }
}




