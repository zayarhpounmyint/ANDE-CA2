package com.example.helloworld;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;

public class RecycleArrayAdapterTrip extends RecyclerView.Adapter{
    Context mContext;
    int total_types;
    private static final int VIEW_TYPE_1 = 1;
    private static final int VIEW_TYPE_2 = 2;
    private static final int VIEW_TYPE_3 = 3;
    private static final int VIEW_TYPE_4 = 4;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
    DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("E, MMM d");

    private LinkedList<Activity_Obj> activities;
    private LinkedList<Activity_Obj> activitiesTemp = addTag();

    private LinkedList<Activity_Obj> addTag(){
        LinkedList<Activity_Obj> activitiesTemp = this.activities;
        activitiesTemp.addFirst(new OtherObj("CD037C6323B67E93215F9CC345DC74C6B99FE3E2CE8AFB02E4AE2B92C6411352",
                activitiesTemp.getFirst().getActivityStartTime(), activitiesTemp.getFirst().getActivityEndTime(),""));
        for(int i = 0; i < activitiesTemp.size(); i ++ ){

            if(areDatesInDifferentDays(activities.get(i).getActivityStartTime(),activities.get(i+1).getActivityStartTime())){
                activitiesTemp.add(i+1,new OtherObj("CD037C6323B67E93215F9CC345DC74C6B99FE3E2CE8AFB02E4AE2B92C6411352",
                        this.activities.get(i+1).getActivityStartTime(), this.activities.get(i+1).getActivityEndTime(),""));
            }
        }
        return activitiesTemp;
    }

    public RecycleArrayAdapterTrip(LinkedList<Activity_Obj> activities) {
        this.activities = activities;

    }

    @Override
    public int getItemViewType(int position) {
        // Return the view type based on the position or data
        if (position == 0) {
            return VIEW_TYPE_1;
        } else if (position == activities.size()-1) {
            return VIEW_TYPE_2;
        } else if (activitiesTemp.get(position).getActivity_Name().equals("CD037C6323B67E93215F9CC345DC74C6B99FE3E2CE8AFB02E4AE2B92C6411352")){
            return  VIEW_TYPE_3;
        } else {
            return VIEW_TYPE_4;
        }

    }
    private static boolean areDatesInDifferentDays(ZonedDateTime date1, ZonedDateTime date2) {
        // Check if the two dates are in different days
        return !date1.toLocalDate().isEqual(date2.toLocalDate());
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        switch (viewType) {
            case VIEW_TYPE_1:
                View type1View = inflater.inflate(R.layout.list_recycleitemobj, parent, false);
                return new HeadNodeHolder(type1View);
            case VIEW_TYPE_2:
                View type2View = inflater.inflate(R.layout.list_recycleitemleaf, parent, false);
                return new LeafHolder(type2View);
            case VIEW_TYPE_3:
                View type3View = inflater.inflate(R.layout.list_recycleitemheader,parent,false);
                return new TagHolder(type3View);
            case VIEW_TYPE_4:
                View type4View = inflater.inflate(R.layout.list_recycleitemnode,parent,false);
                return new NodeHolder(type4View);
            default:
                throw new IllegalArgumentException("Invalid view type");
        }

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        switch (holder.getItemViewType()) {
            case VIEW_TYPE_1:
                ((HeadNodeHolder) holder).bindType1Data(activities.get(position));
                break;
            case VIEW_TYPE_2:
                ((LeafHolder) holder).bindType2Data(activities.get(position));
                break;
            case VIEW_TYPE_3:
                ((TagHolder) holder).bindType3Data(activities.get(position));
                break;
            case VIEW_TYPE_4:
                ((NodeHolder) holder).bindType4Data( activities.get(position));
                break;
        }

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    public class HeadNodeHolder extends RecyclerView.ViewHolder {

        ImageButton detailButton;
        View circle;
        View line;
        TextView timeTxt;
        TextView timeZoneTxt;
        TextView activityHeaderTxt;
        TextView activityDetailTxt;
        View view;
        View view2;
        View placeholder;

        HeadNodeHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize your views here
            detailButton = itemView.findViewById(R.id.activityDetail_btn);
            circle = itemView.findViewById(R.id.circle);
            line = itemView.findViewById(R.id.line_);
            timeTxt = itemView.findViewById(R.id.timeTxt);
            timeZoneTxt = itemView.findViewById(R.id.timeZoneTxt);
            activityHeaderTxt = itemView.findViewById(R.id.activityHeaderTxt);
            activityDetailTxt = itemView.findViewById(R.id.activityDetailTxt);
            view = itemView.findViewById(R.id.view);
            view2 = itemView.findViewById(R.id.view2);
            placeholder = itemView.findViewById(R.id.placeholder1);

        }

        void bindType1Data(Activity_Obj data) {
            timeTxt.setText(data.getActivityStartTime().format(formatter) );
            timeZoneTxt.setText("UTC"+data.getActivityStartTime().getOffset());
            activityHeaderTxt.setText(data.getActivity_Name());
            activityDetailTxt.setText(data.getDisplayText());
        }
    }

    public class NodeHolder extends RecyclerView.ViewHolder {

        ImageButton detailButton;
        View circle;
        View line;
        TextView timeTxt;
        TextView timeZoneTxt;
        TextView activityHeaderTxt;
        TextView activityDetailTxt;
        View view;
        View view2;
        View placeholder;

        NodeHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize your views here
            detailButton = itemView.findViewById(R.id.activityDetail_btn);
            circle = itemView.findViewById(R.id.circle);
            line = itemView.findViewById(R.id.line_);
            timeTxt = itemView.findViewById(R.id.timeTxt);
            timeZoneTxt = itemView.findViewById(R.id.timeZoneTxt);
            activityHeaderTxt = itemView.findViewById(R.id.activityHeaderTxt);
            activityDetailTxt = itemView.findViewById(R.id.activityDetailTxt);
            view = itemView.findViewById(R.id.view);
            view2 = itemView.findViewById(R.id.view2);
            placeholder = itemView.findViewById(R.id.placeholder1);

        }

        void bindType4Data(Activity_Obj data) {
            timeTxt.setText(data.getActivityStartTime().format(formatter) );
            timeZoneTxt.setText("UTC"+data.getActivityStartTime().getOffset());
            activityHeaderTxt.setText(data.getActivity_Name());
            activityDetailTxt.setText(data.getDisplayText());
        }
    }

    public class LeafHolder extends RecyclerView.ViewHolder {

        ImageButton detailButton;
        View circle;
        View line;
        TextView timeTxt;
        TextView timeZoneTxt;
        TextView activityHeaderTxt;
        TextView activityDetailTxt;
        View view;
        View view2;
        View placeholder;

        LeafHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize your views here
            detailButton = itemView.findViewById(R.id.activityDetail_btn);
            circle = itemView.findViewById(R.id.circle);
            line = itemView.findViewById(R.id.line_);
            timeTxt = itemView.findViewById(R.id.timeTxt);
            timeZoneTxt = itemView.findViewById(R.id.timeZoneTxt);
            activityHeaderTxt = itemView.findViewById(R.id.activityHeaderTxt);
            activityDetailTxt = itemView.findViewById(R.id.activityDetailTxt);
            view = itemView.findViewById(R.id.view);
            view2 = itemView.findViewById(R.id.view2);
            placeholder = itemView.findViewById(R.id.placeholder1);
        }

        void bindType2Data(Activity_Obj data) {
            timeTxt.setText(data.getActivityStartTime().format(formatter) );
            timeZoneTxt.setText("UTC"+data.getActivityStartTime().getOffset());
            activityHeaderTxt.setText(data.getActivity_Name());
            activityDetailTxt.setText(data.getDisplayText());
        }
    }

    public class TagHolder extends RecyclerView.ViewHolder {


        TextView listItemHeader;


        TagHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize your views here

            listItemHeader = itemView.findViewById(R.id.listItemHeader);

        }

        void bindType3Data(Activity_Obj data) {
            listItemHeader.setText(data.getActivityStartTime().format(formatter2));

        }
    }


}
