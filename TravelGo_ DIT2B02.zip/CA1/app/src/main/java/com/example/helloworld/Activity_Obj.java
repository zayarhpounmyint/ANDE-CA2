package com.example.helloworld;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.UUID;

public class Activity_Obj implements Serializable {
    private String activity_Name;
    private UUID uuid;
    private ZonedDateTime activityStartTime;
    private ZonedDateTime activityEndTime;

    public Activity_Obj(){

    }

    public Activity_Obj(String activity_Name,  ZonedDateTime activityStartTime, ZonedDateTime activityEndTime) {
        this.activity_Name = activity_Name;
        this.uuid = generateId();
        this.activityStartTime = activityStartTime;
        this.activityEndTime = activityEndTime;
    }

    public String getActivity_Name() {
        return activity_Name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public ZonedDateTime getActivityStartTime() {
        return activityStartTime;
    }

    public ZonedDateTime getActivityEndTime() {
        return activityEndTime;
    }

    public void setActivity_Name(String activity_Name) {
        this.activity_Name = activity_Name;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public void setActivityStartTime(ZonedDateTime activityStartTime) {
        this.activityStartTime = activityStartTime;
    }

    public void setActivityEndTime(ZonedDateTime activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    private static UUID generateId(){

        UUID uuid = UUID.randomUUID();
        return uuid;
    }

    public String getDisplayText(){
        return "";
    }
}
