package com.example.helloworld;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

public class TripPlanActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private LinkedList<Activity_Obj> tripList= new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triptimeline);
        setUIRef();
    }
    private void setUIRef()
    {

        //Reference of RecyclerView
        mRecyclerView = findViewById(R.id.tripPlanRecycleView);
        //Linear Layout Manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        //Set Layout Manager to RecyclerView
        mRecyclerView.setLayoutManager(linearLayoutManager);

        //Create adapter
        RecycleArrayAdapterTrip myRecyclerViewAdapter = new RecycleArrayAdapterTrip(tripList);

        //Set adapter to RecyclerView
        mRecyclerView.setAdapter(myRecyclerViewAdapter);
    }




}
